# Đồ Án Văn Lang Năm 2 - Ngành Kĩ Thuật Phần Mềm

## Lớp 233_71SEMO30054_02 - Kì Hè (2024)

**Giảng Viên:** Nguyễn Thị Bích Ngân

## Đề Tài : Đặc Sản Vùng Miền

### Danh sách đặc sản theo vùng miền:
- **Hiển thị danh sách đặc sản từ các vùng miền khác nhau:** Bắc, Trung, Nam.
- **Phân loại theo loại đặc sản:** món ăn mặn, bánh kẹo, trái cây, thảo dược, đồ uống, v.v.

### Chi tiết đặc sản: Hào
- **Thông tin chi tiết:** Cho phép người dùng xem thông tin chi tiết về một đặc sản cụ thể.
- **Hiển thị:** hình ảnh, nguyên liệu, công thức làm, và lịch sử của đặc sản.

### Tìm kiếm đặc sản: Lộc
- **Chức năng tìm kiếm:** Người dùng có thể tìm đặc sản dựa trên tên, loại, hoặc vùng miền.
- **Kết quả tìm kiếm:** Hiển thị danh sách đặc sản phù hợp.

### Thêm đặc sản mới: Khoa Đăng
- **Đóng góp thông tin:** Cho phép người dùng đóng góp thông tin về đặc sản mà họ biết.
- **Giao diện nhập liệu:** Cung cấp giao diện để nhập tên, hình ảnh, công thức, và mô tả.

### Lưu danh sách yêu thích:
- **Đánh dấu yêu thích:** Người dùng có thể đánh dấu đặc sản yêu thích để dễ dàng theo dõi.
- **Lưu trữ:** Lưu trữ danh sách yêu thích trong ứng dụng.

### Chia sẻ đặc sản: Bá Minh
- **Chia sẻ thông tin:** Cho phép người dùng chia sẻ thông tin về đặc sản qua mạng xã hội hoặc qua tin nhắn.

### Gợi ý đặc sản ngẫu nhiên:
- **Hiển thị ngẫu nhiên:** Hiển thị một đặc sản ngẫu nhiên mỗi khi người dùng mở ứng dụng.

## Thành Viên
- **Hồ Sỹ Hào** - 2274801030043
- **Lý Khoa Đăng** - 2274801030034
- **Nguyễn Quang Lộc** - 2274801030086
- **Nguyễn Huỳnh Gia Bảo** - 2274801030010
- **Bùi Quang Huy** - 2274801030010
- **Phạm Nguyễn Bá Minh** - 2274801030088
